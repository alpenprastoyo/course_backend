const getOrders = require('./getOrders');

module.exports = {
  getOrders
}